package com.PFE.EndOfYearProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EndOfYearProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(EndOfYearProjectApplication.class, args);
	}

}
