package com.PFE.EndOfYearProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EndOfYearProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
